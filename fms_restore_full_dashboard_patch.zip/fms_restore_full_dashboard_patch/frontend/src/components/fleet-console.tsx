"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Pose = { x: number; y: number; yaw: number };
type PhysicalRobot = {
  robot_id: string;
  name: string;
  host: string;
  connection_status: "ssh_connected";
  connection_kind: "ssh_authenticated";
  ssh_online: true;
  pose: Pose | null;
  nav2_ready: boolean | null;
  controller_ready: boolean | null;
};
type PhysicalFleet = {
  robots: PhysicalRobot[];
  configured_count: number;
  connected_count: number;
  checked_at: string;
  data_source: "authenticated_ssh_probe";
};
type PhysicalMap = {
  frame_id: "map";
  width_px: number;
  height_px: number;
  width_m: number;
  height_m: number;
  resolution: number;
  origin: { x: number; y: number; yaw: number };
  image_url: string;
  source: string;
  data_source: "physical_site_map_files";
};

type Task = {
  task_id: string;
  status: string;
  robot_id: string | null;
  destination: { x: number; y: number; yaw: number; label: string };
  owner_epoch: number;
  navigation_goal_count: number;
  recovery_reason: string | null;
  failure_reason: string | null;
  completion_evidence: { goal_status: string; distance_m: number } | null;
};
type Zone = {
  zone_id: string;
  name: string;
  kind: string;
  bounds: { x: number; y: number; w: number; h: number };
  reservation: { reservation_status: string; robot_id: string } | null;
};
type FeedEvent = { kind: string; code: string; message: string; created_at: string | null };

async function readJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(path, { cache: "no-store", signal });
  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const data = await response.json();
      detail = typeof data?.detail === "string" ? data.detail : detail;
    } catch { /* Keep HTTP status if response body is not JSON. */ }
    throw new Error(detail);
  }
  return response.json() as Promise<T>;
}

function statusVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  if (["COMPLETED", "ssh_connected", "online"].includes(status)) return "default";
  if (["FAILED", "RECOVERY_REQUIRED", "offline"].includes(status)) return "destructive";
  if (["RUNNING", "busy"].includes(status)) return "secondary";
  return "outline";
}

export function FleetConsole() {
  const [fleet, setFleet] = useState<PhysicalFleet | null>(null);
  const [physicalMap, setPhysicalMap] = useState<PhysicalMap | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [mapError, setMapError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [label, setLabel] = useState("");
  const [x, setX] = useState("");
  const [y, setY] = useState("");
  const [robotId, setRobotId] = useState("");

  // Existing FMS sections remain, but Phase-1 Mock DB/task/zone/event APIs
  // must NOT be read or rendered as if they were physical robot observations.
  const tasks: Task[] = useMemo(() => [], []);
  const zones: Zone[] = useMemo(() => [], []);
  const active = useMemo(
    () => tasks.filter((task) => !["COMPLETED", "CANCELED", "FAILED"].includes(task.status)),
    [tasks],
  );
  const history = useMemo(
    () => tasks.filter((task) => ["COMPLETED", "CANCELED", "FAILED"].includes(task.status)).slice(0, 8),
    [tasks],
  );
  const events: FeedEvent[] = useMemo(() => {
    if (!fleet) return [];
    return [{
      kind: "ssh_probe",
      code: "ssh_presence_checked",
      message: `설정 대상 ${fleet.configured_count}대 중 SSH 인증 성공 ${fleet.connected_count}대`,
      created_at: fleet.checked_at,
    }];
  }, [fleet]);

  const refresh = useCallback(async (signal?: AbortSignal) => {
    // Independent requests: an absent map should not hide authenticated robots.
    const [robotsResult, mapResult] = await Promise.allSettled([
      readJson<PhysicalFleet>("/fms-api/physical/robots", signal),
      readJson<PhysicalMap>("/fms-api/physical/map", signal),
    ]);
    if (signal?.aborted) return;
    if (robotsResult.status === "fulfilled" && Array.isArray(robotsResult.value.robots)) {
      setFleet(robotsResult.value);
      setLoadError(null);
    } else {
      setFleet(null); // Do not leave stale robots displaying as online.
      setLoadError(robotsResult.status === "rejected"
        ? String(robotsResult.reason instanceof Error ? robotsResult.reason.message : robotsResult.reason)
        : "잘못된 실물 로봇 응답");
    }
    if (mapResult.status === "fulfilled" && Number.isFinite(mapResult.value.width_px)) {
      setPhysicalMap(mapResult.value);
      setMapError(null);
    } else {
      setPhysicalMap(null);
      setMapError(mapResult.status === "rejected"
        ? String(mapResult.reason instanceof Error ? mapResult.reason.message : mapResult.reason)
        : "실제 지도 형식이 올바르지 않습니다.");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void refresh(controller.signal);
    const timer = window.setInterval(() => void refresh(controller.signal), 5000);
    return () => {
      controller.abort();
      window.clearInterval(timer);
    };
  }, [refresh]);

  function chooseDestination(px: number, py: number) {
    if (!physicalMap) return;
    const localX = px * physicalMap.resolution;
    const localY = (physicalMap.height_px - py) * physicalMap.resolution;
    const theta = physicalMap.origin.yaw;
    const worldX = physicalMap.origin.x + localX * Math.cos(theta) - localY * Math.sin(theta);
    const worldY = physicalMap.origin.y + localX * Math.sin(theta) + localY * Math.cos(theta);
    setX(worldX.toFixed(3));
    setY(worldY.toFixed(3));
  }

  const selected = useMemo(() => {
    if (!physicalMap || !x.trim() || !y.trim()) return null;
    const gx = Number(x);
    const gy = Number(y);
    if (!Number.isFinite(gx) || !Number.isFinite(gy)) return null;
    const theta = physicalMap.origin.yaw;
    const dx = gx - physicalMap.origin.x;
    const dy = gy - physicalMap.origin.y;
    const localX = (dx * Math.cos(theta) + dy * Math.sin(theta)) / physicalMap.resolution;
    const localY = (-dx * Math.sin(theta) + dy * Math.cos(theta)) / physicalMap.resolution;
    const px = localX;
    const py = physicalMap.height_px - localY;
    return px >= 0 && px <= physicalMap.width_px && py >= 0 && py <= physicalMap.height_px
      ? { px, py } : null;
  }, [physicalMap, x, y]);

  return (
    <main className="mx-auto flex min-h-screen max-w-7xl flex-col gap-4 px-4 py-5 md:px-6">
      <header className="flex flex-col gap-3 border-b border-border pb-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs tracking-[0.18em] text-primary uppercase">Care ward · physical fleet</p>
          <h1 className="text-2xl font-semibold">Care-Move FMS</h1>
          <p className="max-w-2xl text-sm text-muted-foreground">
            기존 관제 화면을 유지하고, SSH 인증에 성공한 실물 Pinky만 표시합니다.
            SSH 연결 여부와 ROS·Nav2 준비 상태는 별개입니다.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant="outline">RMF 미사용</Badge>
          <Badge variant="outline">실물 관제 조회</Badge>
          <Badge variant="outline">모터 제어 미연동</Badge>
          <Badge variant="outline">SSH {fleet?.connected_count ?? 0}대</Badge>
          <Badge variant="outline">등록 {fleet?.configured_count ?? 0}대</Badge>
          <Badge variant={physicalMap ? "default" : "destructive"}>
            지도 {physicalMap ? "실제 파일" : "미확인"}
          </Badge>
        </div>
      </header>

      {loading && <p className="text-sm text-muted-foreground">실물 Pinky와 실제 지도 확인 중...</p>}
      {loadError && (
        <Card>
          <CardHeader>
            <CardTitle>SSH 로봇 목록 API 연결 오류</CardTitle>
            <CardDescription>{loadError} · Backend(8741) 및 SSH 설정을 확인하세요.</CardDescription>
          </CardHeader>
        </Card>
      )}

      <section className="grid gap-3 md:grid-cols-3">
        {(fleet?.robots ?? []).map((robot) => (
          <Card key={robot.robot_id}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between gap-2">
                <span>{robot.name}</span>
                <span className="font-mono text-xs text-muted-foreground">{robot.robot_id}</span>
              </CardTitle>
              <CardDescription>실물 로봇 · {robot.host}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex flex-wrap gap-1.5">
                <Badge variant={statusVariant(robot.connection_status)}>SSH 연결</Badge>
                <Badge variant="outline">ROS 상태 미확인</Badge>
                <Badge variant="outline">배터리 미연동</Badge>
                <Badge variant="outline">Nav2 미확인</Badge>
              </div>
              <p className="font-mono text-xs text-muted-foreground">
                pose {robot.pose ? `${robot.pose.x.toFixed(2)}, ${robot.pose.y.toFixed(2)}` : "미수신"}
                {robot.pose ? " · 관측값(신뢰도 미확인)" : " · 실시간 위치 미연동"}
              </p>
              <p className="text-xs text-muted-foreground">현재 작업: 실물 Task 연동 전 · SSH 인증 성공</p>
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="outline" disabled title="실제 하드웨어 정지 API가 연결되기 전까지 사용할 수 없습니다.">
                  비상 정지 (미연동)
                </Button>
                <Button type="button" variant="secondary" disabled>정지 래치 해제 (미연동)</Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {!loading && !loadError && (fleet?.robots.length ?? 0) === 0 && (
          <Card>
            <CardHeader>
              <CardTitle>현재 연결된 실물 Pinky가 없습니다</CardTitle>
              <CardDescription>SSH 인증 실패 로봇 및 기존 Mock 로봇은 표시하지 않습니다.</CardDescription>
            </CardHeader>
          </Card>
        )}
      </section>

      <section className="grid gap-4 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,0.7fr)]">
        <Card>
          <CardHeader>
            <CardTitle>현장 지도</CardTitle>
            <CardDescription>
              {physicalMap
                ? `${physicalMap.source} · ${physicalMap.width_m} × ${physicalMap.height_m} m · ${physicalMap.resolution} m/px · frame: ${physicalMap.frame_id}`
                : "FMS/config/maps/physical_site/1f_map.yaml 및 PGM 원본을 사용합니다."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {physicalMap ? (
              <div className="rounded-lg border border-border overflow-hidden">
                <svg
                  role="img"
                  aria-label="기존 물리 현장 지도, 클릭하면 지도 좌표를 작업 입력칸에 기록"
                  viewBox={`0 0 ${physicalMap.width_px} ${physicalMap.height_px}`}
                  className="block h-auto w-full cursor-crosshair"
                  onClick={(event) => {
                    const rect = event.currentTarget.getBoundingClientRect();
                    if (rect.width <= 0 || rect.height <= 0) return;
                    chooseDestination(
                      ((event.clientX - rect.left) / rect.width) * physicalMap.width_px,
                      ((event.clientY - rect.top) / rect.height) * physicalMap.height_px,
                    );
                  }}
                >
                  <image href={physicalMap.image_url} width={physicalMap.width_px} height={physicalMap.height_px} />
                  {selected && (
                    <g aria-label="선택된 좌표(아직 주행 명령 아님)">
                      <circle cx={selected.px} cy={selected.py} r={4} fill="none" stroke="#e34d57" strokeWidth={1.5} />
                      <path d={`M ${selected.px - 7} ${selected.py} h 14 M ${selected.px} ${selected.py - 7} v 14`}
                        stroke="#e34d57" strokeWidth={0.8} />
                    </g>
                  )}
                  {/* No robot marker is drawn without verified, real map-frame pose. */}
                </svg>
              </div>
            ) : (
              <p className="text-sm text-destructive">{mapError ?? "실제 지도 로딩 중..."}</p>
            )}
            <p className="text-xs text-muted-foreground">
              지도를 클릭하면 실제 map 좌표가 아래 작업 입력란에 입력됩니다. 지도에 로봇 위치는 실시간 TF/AMCL 미연동 상태이므로 표시하지 않습니다.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>작업 접수</CardTitle>
            <CardDescription>기존 입력 화면 유지 · 실물 Nav2 Task 연동 전이므로 접수 버튼 비활성화</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="flex flex-col gap-3" onSubmit={(event) => event.preventDefault()}>
              <div className="grid gap-2">
                <Label htmlFor="label">목적지 이름</Label>
                <Input id="label" value={label} onChange={(event) => setLabel(event.target.value)} placeholder="실제 목적지 이름" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="grid gap-2">
                  <Label htmlFor="x">X (m)</Label>
                  <Input id="x" value={x} onChange={(event) => setX(event.target.value)} inputMode="decimal" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="y">Y (m)</Label>
                  <Input id="y" value={y} onChange={(event) => setY(event.target.value)} inputMode="decimal" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="robot">로봇 지정</Label>
                <Input id="robot" list="physical-robots" placeholder="연결된 Pinky를 선택" value={robotId}
                  onChange={(event) => setRobotId(event.target.value)} />
                <datalist id="physical-robots">
                  {(fleet?.robots ?? []).map((robot) => <option key={robot.robot_id} value={robot.robot_id} />)}
                </datalist>
              </div>
              <Button type="submit" disabled>작업 접수 (실물 Nav2 연동 전)</Button>
              <p className="text-xs text-muted-foreground">Mock Task API에는 전송하지 않습니다. 기존 FMS Task 기록은 보존되지만 이 화면에는 표시하지 않습니다.</p>
            </form>
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>작업 대기열 · 실행 중</CardTitle>
            <CardDescription>{active.length === 0 ? "실물 Task 연동 전 · 현재 표시할 작업 없음" : `${active.length}건`}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {active.length === 0 && <p className="text-sm text-muted-foreground">과거 Mock 작업은 제외했습니다. 실제 Nav2 Task 연동 후 작업이 표시됩니다.</p>}
            {active.map((task) => (
              <article key={task.task_id} className="rounded-lg border border-border p-3">
                <div className="flex items-center justify-between">
                  <p>{task.destination.label} · {task.robot_id ?? "미배정"}</p>
                  <Badge variant={statusVariant(task.status)}>{task.status}</Badge>
                </div>
              </article>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>구역 점유</CardTitle>
            <CardDescription>기존 표시 영역 유지 · 실제 구역/예약 상태 미연동</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            {zones.length === 0 && <p className="text-sm text-muted-foreground">실물 지도 기반 구역 데이터가 없어 표시하지 않습니다.</p>}
            {zones.map((zone) => (
              <div key={zone.zone_id} className="flex justify-between rounded-lg border border-border p-2">
                <span>{zone.name}</span>
                <Badge variant="outline">{zone.reservation?.reservation_status ?? "비어 있음"}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>최근 종료</CardTitle>
            <CardDescription>실제 Nav2 결과 기반 종료 기록만 표시할 예정</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            {history.length === 0 && <p className="text-sm text-muted-foreground">검증된 실물 주행 종료 기록이 없습니다.</p>}
            {history.map((task) => (
              <div key={task.task_id} className="flex justify-between text-sm">
                <span>{task.destination.label}</span>
                <Badge variant={statusVariant(task.status)}>{task.status}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>이벤트</CardTitle>
            <CardDescription>실물 SSH 상태 확인 결과 · Mock 이벤트 제외</CardDescription>
          </CardHeader>
          <CardContent className="max-h-80 space-y-2 overflow-auto">
            {events.length === 0 && <p className="text-sm text-muted-foreground">표시할 실물 연결 이벤트가 없습니다.</p>}
            {events.map((item, index) => (
              <div key={`${item.created_at}-${index}`} className="border-b border-border pb-2 text-xs">
                <p className="font-medium">{item.code} <span className="text-muted-foreground">{item.kind}</span></p>
                <p className="text-muted-foreground">{item.message}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>

      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
        <p>마지막 SSH 확인: {fleet?.checked_at ? new Date(fleet.checked_at).toLocaleString("ko-KR") : "연결 확인 전"}</p>
        <Button type="button" variant="outline" size="sm" onClick={() => void refresh()}>새로고침</Button>
      </div>
    </main>
  );
}
