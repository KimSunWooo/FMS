"""Real-device read-only SSH presence and actual physical-site map endpoints.

No simulated robot, pose, battery, task, Nav2 readiness, or motor control is
manufactured by this module. SSH authentication != ROS / navigation readiness.
"""
from __future__ import annotations

import asyncio
import os
import re
import struct
import zlib
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response

router = APIRouter(prefix="/api/physical", tags=["physical"])

_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
_TARGET = re.compile(r"^(?P<user>[A-Za-z_][A-Za-z0-9_-]*)@(?P<host>[A-Za-z0-9][A-Za-z0-9.\-]*)$")
DEFAULT_MAP = Path(__file__).resolve().parents[3] / "config/maps/physical_site/1f_map.yaml"


def parse_targets(config: str) -> list[tuple[str, str]]:
    targets: list[tuple[str, str]] = []
    seen: set[str] = set()
    for item in config.split(","):
        item = item.strip()
        if not item:
            continue
        if "=" not in item:
            raise ValueError("FMS_PHYSICAL_SSH_TARGETS must be id=username@host")
        robot_id, target = (part.strip() for part in item.split("=", 1))
        if not _ID.fullmatch(robot_id) or not _TARGET.fullmatch(target) or robot_id in seen:
            raise ValueError("Invalid or duplicate FMS_PHYSICAL_SSH_TARGETS entry")
        seen.add(robot_id)
        targets.append((robot_id, target))
    return targets


async def check_ssh(robot_id: str, target: str, timeout: float) -> dict | None:
    timeout = max(1.0, min(float(timeout), 8.0))
    try:
        proc = await asyncio.create_subprocess_exec(
            "ssh", "-T", "-n",
            "-o", "BatchMode=yes",
            "-o", "NumberOfPasswordPrompts=0",
            "-o", "StrictHostKeyChecking=yes",
            "-o", "ConnectionAttempts=1",
            "-o", f"ConnectTimeout={int(timeout)}",
            "-o", "LogLevel=ERROR",
            target, "true",
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=timeout + 1.0)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return None
        if proc.returncode != 0:
            return None
    except (OSError, ValueError):
        return None
    return {
        "robot_id": robot_id,
        "name": robot_id,
        "host": target.rsplit("@", 1)[-1],
        "connection_status": "ssh_connected",
        "connection_kind": "ssh_authenticated",
        "ssh_online": True,
        "pose": None,  # No fake location until an actual ROS observation is wired.
        "nav2_ready": None,
        "controller_ready": None,
    }


@router.get("/robots")
async def connected_robots(request: Request) -> dict:
    settings = request.app.state.settings
    targets = parse_targets(settings.physical_ssh_targets)
    result = await asyncio.gather(*(
        check_ssh(robot_id, target, settings.physical_ssh_timeout_seconds)
        for robot_id, target in targets
    ))
    robots = [robot for robot in result if robot is not None]
    return {
        "robots": robots,
        "configured_count": len(targets),
        "connected_count": len(robots),
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "data_source": "authenticated_ssh_probe",
    }


def _map_files() -> tuple[Path, Path, float, list[float]]:
    """Use the already-downloaded Nav2 map on the FMS host, never a demo map."""
    yaml_path = Path(os.getenv("FMS_PHYSICAL_MAP_YAML", str(DEFAULT_MAP))).expanduser()
    try:
        lines = yaml_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise HTTPException(503, f"Actual map YAML unavailable: {yaml_path}: {exc}") from exc
    meta: dict[str, str] = {}
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = value.strip()
    if not meta.get("image"):
        raise HTTPException(503, "Map YAML has no 'image' field")
    raw_image = meta["image"].strip('"\'')
    image = Path(raw_image)
    if not image.is_absolute():
        image = yaml_path.parent / image
    if image.suffix.lower() != ".pgm":
        raise HTTPException(503, "Expected the downloaded Nav2 .pgm map image")
    try:
        resolution = float(meta["resolution"])
        origin = [float(x) for x in meta["origin"].strip("[]").split(",")]
    except (KeyError, ValueError) as exc:
        raise HTTPException(503, "Invalid map YAML origin/resolution") from exc
    if resolution <= 0 or len(origin) != 3:
        raise HTTPException(503, "Invalid map geometry")
    return yaml_path, image, resolution, origin


def _read_pgm(path: Path) -> tuple[int, int, bytes]:
    """Decode the standard P5/P2 PGM used by Nav2 without Pillow/ROS imports."""
    try:
        content = path.read_bytes()
    except OSError as exc:
        raise HTTPException(503, f"Actual map PGM unavailable: {path}: {exc}") from exc
    pos = 0

    def token() -> bytes:
        nonlocal pos
        while pos < len(content):
            if content[pos] in b" \r\n\t":
                pos += 1
            elif content[pos] == ord("#"):
                while pos < len(content) and content[pos] not in b"\r\n":
                    pos += 1
            else:
                break
        start = pos
        while pos < len(content) and content[pos] not in b" \r\n\t":
            pos += 1
        if start == pos:
            raise ValueError("Truncated PGM header")
        return content[start:pos]

    try:
        fmt = token()
        width, height, max_value = int(token()), int(token()), int(token())
        if fmt not in (b"P5", b"P2") or width <= 0 or height <= 0 or not 1 <= max_value <= 65535:
            raise ValueError("Invalid PGM header")
        pixels = width * height
        if pixels > 50_000_000:
            raise ValueError("Map image exceeds size limit")
        if fmt == b"P5":
            if pos >= len(content) or content[pos] not in b" \r\n\t":
                raise ValueError("Invalid PGM payload separator")
            if content[pos:pos + 2] == b"\r\n":
                pos += 2
            else:
                pos += 1
            count = pixels * (2 if max_value > 255 else 1)
            raw = content[pos:pos + count]
            if len(raw) != count:
                raise ValueError("Incomplete PGM pixels")
            if max_value > 255:
                values = struct.unpack(f">{pixels}H", raw)
                gray = bytes(round(value * 255 / max_value) for value in values)
            elif max_value != 255:
                gray = bytes(round(value * 255 / max_value) for value in raw)
            else:
                gray = raw
        else:
            values = [int(token()) for _ in range(pixels)]
            gray = bytes(round(value * 255 / max_value) for value in values)
        return width, height, gray
    except (ValueError, IndexError, struct.error) as exc:
        raise HTTPException(503, f"Could not decode actual PGM map: {exc}") from exc


def _png_gray(width: int, height: int, pixels: bytes) -> bytes:
    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    rows = b"".join(b"\x00" + pixels[y * width:(y + 1) * width] for y in range(height))
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">2I5B", width, height, 8, 0, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(rows, level=6))
        + chunk(b"IEND", b"")
    )


@router.get("/map")
def physical_map() -> dict:
    yaml_path, pgm_path, resolution, origin = _map_files()
    width, height, _ = _read_pgm(pgm_path)
    return {
        "frame_id": "map",
        "width_px": width,
        "height_px": height,
        "width_m": round(width * resolution, 6),
        "height_m": round(height * resolution, 6),
        "resolution": resolution,
        "origin": {"x": origin[0], "y": origin[1], "yaw": origin[2]},
        "image_url": "/fms-api/physical/map/image",
        "source": yaml_path.name,
        "data_source": "physical_site_map_files",
    }


@router.get("/map/image")
def physical_map_image() -> Response:
    _, pgm_path, _, _ = _map_files()
    width, height, pixels = _read_pgm(pgm_path)
    return Response(_png_gray(width, height, pixels), media_type="image/png", headers={"Cache-Control": "no-store"})
